document.addEventListener("DOMContentLoaded", () => {
  // Mobile navigation
  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  if (menuButton && nav) {
    menuButton.addEventListener("click", () => nav.classList.toggle("open"));
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));
  }

  // Service search
  const search = document.getElementById("serviceSearch");
  if (search) {
    const cards = [...document.querySelectorAll(".searchable")];
    const empty = document.getElementById("emptyState");
    search.addEventListener("input", () => {
      const term = search.value.trim().toLowerCase();
      let visible = 0;
      cards.forEach(card => {
        const match = (card.dataset.name + " " + card.innerText).toLowerCase().includes(term);
        card.classList.toggle("hidden", !match);
        if (match) visible++;
      });
      empty.classList.toggle("hidden", visible !== 0);
    });
  }

  // Clicking a service pre-selects it in the request form
  document.querySelectorAll(".choose-service").forEach(button => {
    button.addEventListener("click", () => {
      const select = document.getElementById("serviceSelect");
      if (select) {
        select.value = button.dataset.service;
        document.getElementById("request-form").scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // Demo form handler: stores entries in this browser only.
  function handleDemoForm(formId, storageKey, successText) {
    const form = document.getElementById(formId);
    if (!form) return;
    form.addEventListener("submit", event => {
      event.preventDefault();
      const message = form.querySelector(".form-message");
      if (!form.reportValidity()) return;
      const entry = Object.fromEntries(new FormData(form).entries());
      entry.submittedAt = new Date().toISOString();
      try {
        const previous = JSON.parse(localStorage.getItem(storageKey) || "[]");
        previous.push(entry);
        localStorage.setItem(storageKey, JSON.stringify(previous));
        message.textContent = successText;
        message.className = "form-message success";
        form.reset();
      } catch (error) {
        message.textContent = "Your browser could not save this demo entry. Please try again.";
        message.className = "form-message error";
      }
    });
  }

  handleDemoForm("helpForm", "seniorconnect_help_requests",
    "Request saved in this browser demo. No helper has been contacted.");
  handleDemoForm("helperForm", "seniorconnect_helper_signups",
    "Registration saved in this browser demo. Your identity has not been verified.");
  handleDemoForm("contactForm", "seniorconnect_messages",
    "Message saved in this browser demo. It has not been sent to a real support team.");
});